require 'test_helper'

class ResumesHelperTest < ActionView::TestCase
end
