# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Haripriya::Application.config.secret_token = '558263304f5d19247a3ce147e50026ec3868ae3439adb16bad72a0c950b4b12e649d43aec17c5bdda2999da73f5ee8036c1f29af2973260b3944c7eb1e02ff39'
