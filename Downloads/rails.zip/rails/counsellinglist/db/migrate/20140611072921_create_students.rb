class CreateStudents < ActiveRecord::Migration
  def change
    create_table :students do |t|
      t.integer :rollid
      t.string :studentname
      t.string :deptname
      t.string :counsellername
      t.string :college
      t.text :report

      t.timestamps
    end
  end
end
