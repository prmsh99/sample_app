class CreateCollegenames < ActiveRecord::Migration
  def change
    create_table :collegenames do |t|
      t.string :collegename

      t.timestamps
    end
  end
end
