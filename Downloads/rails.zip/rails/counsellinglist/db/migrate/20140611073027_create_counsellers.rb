class CreateCounsellers < ActiveRecord::Migration
  def change
    create_table :counsellers do |t|
      t.string :counsellername

      t.timestamps
    end
  end
end
