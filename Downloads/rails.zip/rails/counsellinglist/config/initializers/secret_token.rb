# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Counsellinglist::Application.config.secret_token = '9e03e8a210b7669bc75338c355bfd5a9a91671cfd4a73f0e3435c446e3ac34c1bb6488196ef3b9f9794ca6ee06bf03cfb1099b650fd6358ff60751df08c36851'
