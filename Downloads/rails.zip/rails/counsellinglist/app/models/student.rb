class Student < ActiveRecord::Base
  attr_accessible :college, :counsellername, :deptname, :report, :rollid, :studentname
  belongs_to :collegename
  belongs_to :counseller
  belongs_to :dept
end
