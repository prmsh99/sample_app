class Dept < ActiveRecord::Base
  attr_accessible :deptname
  has_many :students
end
