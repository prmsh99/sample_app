class Counseller < ActiveRecord::Base
  attr_accessible :counsellername
  has_many :students
end
