class Collegename < ActiveRecord::Base
  attr_accessible :collegename
end
