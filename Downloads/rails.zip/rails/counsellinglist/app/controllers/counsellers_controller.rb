class CounsellersController < ApplicationController
  # GET /counsellers
  # GET /counsellers.json
  def index
    @counsellers = Counseller.all

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @counsellers }
    end
  end

  # GET /counsellers/1
  # GET /counsellers/1.json
  def show
    @counseller = Counseller.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @counseller }
    end
  end

  # GET /counsellers/new
  # GET /counsellers/new.json
  def new
    @counseller = Counseller.new

    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @counseller }
    end
  end

  # GET /counsellers/1/edit
  def edit
    @counseller = Counseller.find(params[:id])
  end

  # POST /counsellers
  # POST /counsellers.json
  def create
    @counseller = Counseller.new(params[:counseller])

    respond_to do |format|
      if @counseller.save
        format.html { redirect_to @counseller, notice: 'Counseller was successfully created.' }
        format.json { render json: @counseller, status: :created, location: @counseller }
      else
        format.html { render action: "new" }
        format.json { render json: @counseller.errors, status: :unprocessable_entity }
      end
    end
  end

  # PUT /counsellers/1
  # PUT /counsellers/1.json
  def update
    @counseller = Counseller.find(params[:id])

    respond_to do |format|
      if @counseller.update_attributes(params[:counseller])
        format.html { redirect_to @counseller, notice: 'Counseller was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: "edit" }
        format.json { render json: @counseller.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /counsellers/1
  # DELETE /counsellers/1.json
  def destroy
    @counseller = Counseller.find(params[:id])
    @counseller.destroy

    respond_to do |format|
      format.html { redirect_to counsellers_url }
      format.json { head :no_content }
    end
  end
end
