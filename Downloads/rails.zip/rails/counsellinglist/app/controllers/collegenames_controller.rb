class CollegenamesController < ApplicationController
  # GET /collegenames
  # GET /collegenames.json
  def index
    @collegenames = Collegename.all

    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @collegenames }
    end
  end

  # GET /collegenames/1
  # GET /collegenames/1.json
  def show
    @collegename = Collegename.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @collegename }
    end
  end

  # GET /collegenames/new
  # GET /collegenames/new.json
  def new
    @collegename = Collegename.new

    respond_to do |format|
      format.html # new.html.erb
      format.json { render json: @collegename }
    end
  end

  # GET /collegenames/1/edit
  def edit
    @collegename = Collegename.find(params[:id])
  end

  # POST /collegenames
  # POST /collegenames.json
  def create
    @collegename = Collegename.new(params[:collegename])

    respond_to do |format|
      if @collegename.save
        format.html { redirect_to @collegename, notice: 'Collegename was successfully created.' }
        format.json { render json: @collegename, status: :created, location: @collegename }
      else
        format.html { render action: "new" }
        format.json { render json: @collegename.errors, status: :unprocessable_entity }
      end
    end
  end

  # PUT /collegenames/1
  # PUT /collegenames/1.json
  def update
    @collegename = Collegename.find(params[:id])

    respond_to do |format|
      if @collegename.update_attributes(params[:collegename])
        format.html { redirect_to @collegename, notice: 'Collegename was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: "edit" }
        format.json { render json: @collegename.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /collegenames/1
  # DELETE /collegenames/1.json
  def destroy
    @collegename = Collegename.find(params[:id])
    @collegename.destroy

    respond_to do |format|
      format.html { redirect_to collegenames_url }
      format.json { head :no_content }
    end
  end
end
