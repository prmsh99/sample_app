module CollegesHelper
end
