require 'test_helper'

class CounsellersControllerTest < ActionController::TestCase
  setup do
    @counseller = counsellers(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:counsellers)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create counseller" do
    assert_difference('Counseller.count') do
      post :create, counseller: { counsellername: @counseller.counsellername }
    end

    assert_redirected_to counseller_path(assigns(:counseller))
  end

  test "should show counseller" do
    get :show, id: @counseller
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @counseller
    assert_response :success
  end

  test "should update counseller" do
    put :update, id: @counseller, counseller: { counsellername: @counseller.counsellername }
    assert_redirected_to counseller_path(assigns(:counseller))
  end

  test "should destroy counseller" do
    assert_difference('Counseller.count', -1) do
      delete :destroy, id: @counseller
    end

    assert_redirected_to counsellers_path
  end
end
