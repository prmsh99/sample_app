require 'test_helper'

class CollegenamesControllerTest < ActionController::TestCase
  setup do
    @collegename = collegenames(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:collegenames)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create collegename" do
    assert_difference('Collegename.count') do
      post :create, collegename: { collegename: @collegename.collegename }
    end

    assert_redirected_to collegename_path(assigns(:collegename))
  end

  test "should show collegename" do
    get :show, id: @collegename
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @collegename
    assert_response :success
  end

  test "should update collegename" do
    put :update, id: @collegename, collegename: { collegename: @collegename.collegename }
    assert_redirected_to collegename_path(assigns(:collegename))
  end

  test "should destroy collegename" do
    assert_difference('Collegename.count', -1) do
      delete :destroy, id: @collegename
    end

    assert_redirected_to collegenames_path
  end
end
