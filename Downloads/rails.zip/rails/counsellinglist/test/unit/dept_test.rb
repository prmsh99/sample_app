require 'test_helper'

class DeptTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
