require 'test_helper'

class CounsellersHelperTest < ActionView::TestCase
end
