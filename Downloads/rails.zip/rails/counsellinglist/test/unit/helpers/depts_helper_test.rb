require 'test_helper'

class DeptsHelperTest < ActionView::TestCase
end
