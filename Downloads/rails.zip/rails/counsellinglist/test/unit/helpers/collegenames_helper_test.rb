require 'test_helper'

class CollegenamesHelperTest < ActionView::TestCase
end
