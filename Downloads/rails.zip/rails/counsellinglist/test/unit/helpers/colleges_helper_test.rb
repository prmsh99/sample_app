require 'test_helper'

class CollegesHelperTest < ActionView::TestCase
end
