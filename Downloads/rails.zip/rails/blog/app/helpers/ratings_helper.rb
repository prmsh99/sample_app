module RatingsHelper
end
