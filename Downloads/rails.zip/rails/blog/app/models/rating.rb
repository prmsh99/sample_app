class Rating < ActiveRecord::Base
  attr_accessible :rank
  has_many :articles
end
