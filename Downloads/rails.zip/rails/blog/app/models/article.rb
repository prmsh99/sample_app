class Article < ActiveRecord::Base
  attr_accessible :category_id, :content, :title
  belongs_to :film
  belongs_to :rating
end
