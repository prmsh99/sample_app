# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Blog::Application.config.secret_token = '7129292f351e49282de94246f9ea4b5798da9c00488464e87f92e8717e399785ffe554ea5b3db77a0fce83228c73981d7d6863c76fbcad60495ad11dd78f3359'
