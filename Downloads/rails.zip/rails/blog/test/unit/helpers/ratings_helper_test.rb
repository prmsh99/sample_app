require 'test_helper'

class RatingsHelperTest < ActionView::TestCase
end
