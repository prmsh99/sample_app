require 'test_helper'

class FilmsHelperTest < ActionView::TestCase
end
